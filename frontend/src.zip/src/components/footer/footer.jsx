import styles from "./footer.module.css";
import { PiWhatsappLogoDuotone, PiInstagramLogoDuotone } from "react-icons/pi";

export default function Footer() {
  return (
    <footer className={styles.footer}>
      <div>
        {/* 
        <h1 className={styles.footerTitle}>Pety & Vanesinha</h1>
        <h2 className={styles.footerSubtitle}>Gafieira SÃo Paulo</h2>
      </div>
      <div className={styles.footerIcons}>
        <h3>Entre em contato</h3>
        <div>
          <PiWhatsappLogoDuotone />
          <PiInstagramLogoDuotone />
        </div>
        */}
      </div>
    </footer>
  );
};

